import { useEffect, useState, type FormEvent } from "react";
import developmentImage from "./assets/development.webp";
import johannesburgImage from "./assets/johannesburg.webp";

const services = [
  {
    number: "01",
    title: "Website Design & Development",
    copy: "Turn more visitors into qualified enquiries with a fast, credible website built around your customer journey.",
    detail: "Strategy, UX, interface design, responsive development and technical SEO.",
    visual: "responsive",
  },
  {
    number: "02",
    title: "E-Commerce",
    copy: "Remove friction from product discovery and checkout with a store designed to build confidence and drive sales.",
    detail: "Store architecture, product UX, payment integration and conversion optimisation.",
    visual: "store",
  },
  {
    number: "03",
    title: "Web Applications",
    copy: "Reduce manual work and give teams better visibility with digital tools built around how your business operates.",
    detail: "Product strategy, dashboards, portals, integrations and scalable front-end development.",
    visual: "dashboard",
  },
  {
    number: "04",
    title: "UI/UX Design",
    copy: "Make complex products easier to understand and use through evidence-led journeys and consistent interfaces.",
    detail: "Research, user flows, wireframes, prototypes and accessible design systems.",
    visual: "wireframes",
  },
  {
    number: "05",
    title: "Website Maintenance",
    copy: "Protect your digital investment with dependable updates, monitoring and performance improvements.",
    detail: "Updates, monitoring, content support, backups and performance improvements.",
    visual: "code",
  },
  {
    number: "06",
    title: "Digital Strategy",
    copy: "Focus budget and effort on the right priorities with a practical roadmap connected to commercial goals.",
    detail: "Discovery, positioning, content planning, analytics and growth recommendations.",
    visual: "strategy",
  },
];

const work = [
  {
    type: "Service business",
    title: "A clearer path from visit to enquiry",
    copy: "A conversion-led website direction built around focused messaging, trust and a frictionless mobile experience.",
    tags: ["Strategy", "Web design", "Development"],
    visual: "service",
    challenge: "The offer is difficult to understand and key trust signals are buried.",
    solution: "Restructure the journey around customer questions, proof and a focused enquiry path.",
    result: "Verified project outcome to be added when client data is available.",
  },
  {
    type: "E-commerce",
    title: "Making product discovery feel effortless",
    copy: "A premium storefront concept that prioritises product clarity, confident purchasing and repeatable content.",
    tags: ["E-commerce UX", "UI design", "Optimisation"],
    visual: "commerce",
    challenge: "A broad catalogue makes it difficult for customers to find the right product.",
    solution: "Create clearer collections, stronger product storytelling and a low-friction purchase flow.",
    result: "Verified project outcome to be added when client data is available.",
  },
  {
    type: "Web application",
    title: "Turning complex workflows into simple actions",
    copy: "A focused dashboard experience designed to surface priorities and reduce day-to-day operational friction.",
    tags: ["Product strategy", "UI/UX", "Front-end"],
    visual: "application",
    challenge: "Teams rely on disconnected tools and cannot see priorities at a glance.",
    solution: "Unify critical tasks and reporting in a role-focused dashboard with clear system feedback.",
    result: "Verified project outcome to be added when client data is available.",
  },
];

const principles = [
  {
    number: "01",
    title: "Business before decoration",
    copy: "Every design decision starts with your goals, customers and commercial reality.",
  },
  {
    number: "02",
    title: "Performance is designed in",
    copy: "Fast loading, responsive behaviour and search fundamentals are part of the build—not extras.",
  },
  {
    number: "03",
    title: "Distinct, never off-the-shelf",
    copy: "Your website is shaped around your brand and proposition instead of a recycled template.",
  },
  {
    number: "04",
    title: "A partner after launch",
    copy: "We remain available for maintenance, improvements and the next stage of your growth.",
  },
];

const process = [
  ["01", "Discovery", "We clarify your goals, audience, offer and the role your website needs to play."],
  ["02", "Strategy", "We shape the structure, messaging and conversion journey before visual design begins."],
  ["03", "Design", "We create a polished interface and refine it with your feedback."],
  ["04", "Development", "We build a responsive, accessible and performance-conscious experience."],
  ["05", "Launch & Support", "We test, launch and stay close as your website starts working in the real world."],
];

const packages = [
  {
    name: "Starter",
    price: "R6,500",
    suffix: "once-off",
    description: "For smaller businesses that need a credible, professional online presence.",
    items: ["Professional 1–3 page website", "Responsive design", "Contact form", "Basic SEO setup"],
  },
  {
    name: "Business",
    price: "R14,500",
    suffix: "once-off",
    description: "For established businesses ready to attract and convert more customers.",
    items: ["Up to 7 custom-designed pages", "Forms + WhatsApp integration", "Basic SEO + analytics setup", "30 days support"],
    featured: true,
  },
  {
    name: "Premium",
    price: "R29,500",
    suffix: "from",
    description: "For advanced websites requiring more content, functionality and integrations.",
    items: ["Up to 15 pages + CMS", "Advanced integrations + SEO foundations", "Booking or e-commerce functionality", "90 days support"],
  },
  {
    name: "Custom Solutions",
    price: "Quotation",
    suffix: "tailored scope",
    description: "For e-commerce, web applications, integrations and complex digital products.",
    items: ["Discovery-led scope", "Custom functionality", "Systems integration", "Support options"],
  },
];

const comparisons = [
  ["Pages", "1–3", "Up to 7", "Up to 15", "Custom"],
  ["Custom interface design", "Focused", "Included", "Included", "Included"],
  ["Forms", "Contact", "Advanced", "Advanced", "Custom"],
  ["WhatsApp integration", "—", "Included", "Included", "Optional"],
  ["CMS", "—", "Optional", "Included", "As required"],
  ["SEO foundations", "Basic", "Basic", "Advanced", "Tailored"],
  ["Analytics setup", "—", "Included", "Included", "As required"],
  ["Booking / e-commerce", "—", "—", "Included", "As required"],
  ["Post-launch support", "7 days", "30 days", "90 days", "Agreed scope"],
];

const faqs = [
  ["How long does a website take?", "A focused small-business website typically takes a few weeks, while larger websites and applications require a longer, phased delivery. Your proposal will include a realistic timeline based on scope, content and feedback requirements."],
  ["What do I need to provide?", "We will guide you through the process. Typically, we need your brand assets, service or product information, preferred imagery and timely feedback. Content support can be scoped separately if required."],
  ["Are hosting and domain fees included?", "No. Domains, hosting, paid plugins or software, advertising costs and substantial content creation may be billed separately. These costs are always discussed before work begins."],
  ["Can you redesign my existing website?", "Yes. We can audit what is working, retain useful content or functionality, and improve the structure, messaging, design and performance around your current business goals."],
  ["Will I be able to update the website?", "Where content changes are important, we can include CMS functionality and provide a practical handover. The right approach depends on your package and ongoing content needs."],
  ["Do you offer support after launch?", "Yes. Every website includes a defined post-launch support period, and ongoing maintenance can be arranged for updates, monitoring, improvements and content support."],
];

function Arrow({ diagonal = false }: { diagonal?: boolean }) {
  return (
    <svg className={diagonal ? "icon diagonal" : "icon"} viewBox="0 0 24 24" aria-hidden="true">
      <path d="M5 12h14M13 6l6 6-6 6" />
    </svg>
  );
}

function Plus({ open }: { open: boolean }) {
  return (
    <span className={open ? "plus is-open" : "plus"} aria-hidden="true">
      <i />
      <i />
    </span>
  );
}

function ServiceVisual({ type }: { type: string }) {
  if (type === "responsive") {
    return (
      <div className="service-visual responsive-visual" aria-label="Responsive website shown on laptop, tablet and phone">
        <div className="device laptop"><i /><b>Better business<br />starts here.</b><span /></div>
        <div className="device tablet"><i /><b>Built to<br />perform.</b></div>
        <div className="device phone"><i /><span /><span /><span /></div>
      </div>
    );
  }
  if (type === "store") {
    return (
      <div className="service-visual store-visual" aria-label="Modern online store interface">
        <div className="store-nav"><b>FORM</b><span>Shop &nbsp; Journal &nbsp; Cart (2)</span></div>
        <div className="store-products"><i /><i /><i /></div>
        <div className="store-details"><span>New collection</span><b>Objects for every day.</b></div>
      </div>
    );
  }
  if (type === "dashboard") {
    return (
      <div className="service-visual dashboard-visual" aria-label="SaaS analytics dashboard">
        <div className="dash-side"><b>M</b><i /><i /><i /></div>
        <div className="dash-main"><span>PERFORMANCE</span><b>Overview</b><i className="dash-chart" /><div><i /><i /><i /></div></div>
      </div>
    );
  }
  if (type === "wireframes") {
    return (
      <div className="service-visual wireframe-visual" aria-label="Interface wireframes and design system components">
        <div className="wire-page"><span /><b /><i /><i /></div>
        <div className="wire-page second"><span /><b /><i /><i /></div>
        <div className="swatches"><i /><i /><i /></div>
      </div>
    );
  }
  if (type === "code") {
    return (
      <div className="service-visual code-visual">
        <img src={developmentImage} alt="Code displayed across a modern development workstation" loading="lazy" />
        <div><span>STATUS</span><b><i /> Systems operational</b></div>
      </div>
    );
  }
  return (
    <div className="service-visual strategy-visual" aria-label="Digital strategy roadmap">
      <div className="strategy-path"><span>Discover</span><span>Define</span><span>Deliver</span></div>
      <i />
      <b>01</b>
    </div>
  );
}

export default function App() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [openProject, setOpenProject] = useState<number | null>(null);
  const [selectedPackage, setSelectedPackage] = useState("Business");
  const [submitted, setSubmitted] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 24);
    handleScroll();
    window.addEventListener("scroll", handleScroll, { passive: true });

    const observer = new IntersectionObserver(
      (entries) => entries.forEach((entry) => {
        if (entry.isIntersecting) entry.target.classList.add("is-visible");
      }),
      { threshold: 0.12 },
    );
    document.querySelectorAll("[data-reveal]").forEach((element) => observer.observe(element));

    return () => {
      window.removeEventListener("scroll", handleScroll);
      observer.disconnect();
    };
  }, []);

  const closeMenu = () => setMenuOpen(false);
  const submitForm = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setSubmitted(true);
  };

  return (
    <div className="site">
      <header className={scrolled ? "navbar scrolled" : "navbar"}>
        <a className="logo" href="#top" aria-label="Mtika Web Solutions home" onClick={closeMenu}>
          <span className="logo-mark">M</span>
          <span>MTIKA <b>WEB SOLUTIONS</b></span>
        </a>

        <nav className={menuOpen ? "nav-menu open" : "nav-menu"} aria-label="Main navigation">
          <a href="#services" onClick={closeMenu}>Services</a>
          <a href="#work" onClick={closeMenu}>Our Work</a>
          <a href="#about" onClick={closeMenu}>About</a>
          <a href="#process" onClick={closeMenu}>Process</a>
          <a href="#contact" onClick={closeMenu}>Contact</a>
        </nav>

        <a className="button button-gold nav-button" href="#contact">
          Start a Project <Arrow />
        </a>

        <button
          className={menuOpen ? "menu-toggle active" : "menu-toggle"}
          type="button"
          aria-label={menuOpen ? "Close navigation" : "Open navigation"}
          aria-expanded={menuOpen}
          onClick={() => setMenuOpen((value) => !value)}
        >
          <span /><span />
        </button>
      </header>

      <main id="top">
        <section className="hero">
          <div className="hero-grid" aria-hidden="true" />
          <div className="hero-copy" data-reveal>
            <div className="kicker"><span /> South African digital agency</div>
            <h1>Digital experiences built to <em>move business forward.</em></h1>
            <p>
              Mtika Web Solutions designs and develops high-performing websites,
              online stores and web applications that help ambitious businesses
              look credible, work smarter and convert more customers.
            </p>
            <div className="hero-actions">
              <a className="button button-gold" href="#contact">Start a Project <Arrow /></a>
              <a className="button button-ghost" href="#work">View Our Work <Arrow /></a>
            </div>
            <div className="hero-trust" aria-label="How we work">
              <span>Strategy-led</span>
              <span>Custom designed</span>
              <span>Built in South Africa</span>
            </div>
          </div>

          <div className="hero-visual" data-reveal>
            <div className="visual-halo" />
            <div className="site-window">
              <div className="window-bar">
                <span /><span /><span />
                <i>mtika.co.za</i>
              </div>
              <div className="window-body">
                <div className="window-nav"><b>M.</b><span>Work &nbsp; Studio &nbsp; Contact</span></div>
                <div className="window-copy">
                  <small>DESIGNED FOR MOMENTUM</small>
                  <strong>Make your<br />next move.</strong>
                  <i />
                </div>
                <div className="window-cards"><span /><span /><span /></div>
              </div>
            </div>
            <div className="visual-note note-one"><span>01</span> Clear strategy</div>
            <div className="visual-note note-two"><span>02</span> Considered design</div>
            <svg className="visual-line" viewBox="0 0 200 120" aria-hidden="true">
              <path d="M5 110C55 105 45 30 105 49s55-34 90-40" />
            </svg>
          </div>

          <a className="scroll-cue" href="#services">
            <span>Scroll to explore</span><i />
          </a>
        </section>

        <section className="credibility" aria-label="Mtika Web Solutions approach">
          <span>Built for real business outcomes</span>
          <div>
            <b>Responsive by default</b>
            <b>Search-ready foundations</b>
            <b>Direct collaboration</b>
            <b>Support beyond launch</b>
          </div>
        </section>

        <section className="trust section">
          <div className="trust-image" data-reveal>
            <img src={johannesburgImage} alt="Johannesburg skyline at golden hour" loading="lazy" />
            <span>South African perspective · Global digital standards</span>
          </div>
          <div className="trust-copy" data-reveal>
            <div className="kicker dark"><span /> Built on clarity</div>
            <h2>A digital partner that treats your website like part of the business.</h2>
            <p>
              Good digital work starts with understanding the commercial context.
              We keep communication direct, make recommendations in plain language
              and design every deliverable to support a real business objective.
            </p>
            <div className="trust-points">
              <div><span>01</span><b>Clear scope and expectations</b></div>
              <div><span>02</span><b>Direct access throughout the project</b></div>
              <div><span>03</span><b>Transparent handover and support</b></div>
            </div>
          </div>
        </section>

        <section className="services section" id="services">
          <div className="section-intro" data-reveal>
            <div>
              <div className="kicker dark"><span /> What we do</div>
              <h2>Digital capability,<br /><em>connected end to end.</em></h2>
            </div>
            <p>
              One strategic partner for the thinking, design and technology your
              business needs to create a stronger digital presence.
            </p>
          </div>

          <div className="service-grid">
            {services.map((service) => (
              <article className="service-card" key={service.number} data-reveal>
                <div className="service-top">
                  <span>{service.number}</span>
                  <Arrow diagonal />
                </div>
                <ServiceVisual type={service.visual} />
                <h3>{service.title}</h3>
                <p>{service.copy}</p>
                <small>{service.detail}</small>
              </article>
            ))}
          </div>
        </section>

        <section className="technology section">
          <div className="technology-heading" data-reveal>
            <div className="kicker"><span /> Technology & platforms</div>
            <h2>The right tools for the job, <em>not technology for its own sake.</em></h2>
            <p>
              We select platforms around your content, operations, budget and
              growth plans—so the final product remains practical to manage.
            </p>
          </div>
          <div className="platform-grid" aria-label="Technology platforms">
            {["React", "WordPress", "Shopify", "WooCommerce", "Webflow", "Vite"].map((platform, index) => (
              <div key={platform} data-reveal>
                <span>0{index + 1}</span><b>{platform}</b>
              </div>
            ))}
          </div>
        </section>

        <section className="work section" id="work">
          <div className="work-heading" data-reveal>
            <div className="kicker"><span /> Selected capabilities</div>
            <h2>Designed around the<br /><em>work your business needs.</em></h2>
            <p>
              A look at the kinds of digital experiences we create. Detailed
              project examples can be shared during your consultation.
            </p>
          </div>

          <div className="project-list">
            {work.map((project, index) => (
              <article className="project" key={project.title} data-reveal>
                <div className={`project-visual ${project.visual}`}>
                  <span className="project-label">{project.type}</span>
                  {project.visual === "service" && (
                    <div className="mock-browser service-mock">
                      <div className="mock-nav"><b>STUDIO / ONE</b><span>Expertise &nbsp; About &nbsp; Enquire</span></div>
                      <strong>Built for<br />what’s next.</strong>
                      <div className="mock-orb" />
                    </div>
                  )}
                  {project.visual === "commerce" && (
                    <div className="commerce-mock">
                      <div className="product-image"><span>Form / 01</span><i /></div>
                      <div className="product-copy"><small>THE DAILY EDIT</small><strong>Essential objects,<br />considered well.</strong><span>Explore collection →</span></div>
                    </div>
                  )}
                  {project.visual === "application" && (
                    <div className="app-mock">
                      <aside><b>M.</b><i /><i /><i /></aside>
                      <div><small>OVERVIEW</small><strong>Good morning.</strong><span className="chart" /><span className="app-rows" /></div>
                    </div>
                  )}
                </div>
                <div className="project-info">
                  <div>
                    <span>{project.type}</span>
                    <h3>{project.title}</h3>
                    <div className="project-tags">
                      {project.tags.map((tag) => <small key={tag}>{tag}</small>)}
                    </div>
                  </div>
                  <button
                    type="button"
                    aria-expanded={openProject === index}
                    onClick={() => setOpenProject(openProject === index ? null : index)}
                  >
                    Our approach <Plus open={openProject === index} />
                  </button>
                </div>
                <div className={openProject === index ? "project-detail open" : "project-detail"}>
                  <p>{project.copy}</p>
                  <div className="case-fields">
                    <div><span>Challenge</span><p>{project.challenge}</p></div>
                    <div><span>Solution</span><p>{project.solution}</p></div>
                    <div className="result-field"><span>Measured result</span><p>{project.result}</p></div>
                  </div>
                  <a href="#contact">Discuss a similar project <Arrow /></a>
                </div>
              </article>
            ))}
          </div>
        </section>

        <section className="why section" id="about">
          <div className="why-lead" data-reveal>
            <div className="kicker dark"><span /> Why Mtika</div>
            <h2>A website should be a business asset, <em>not a digital brochure.</em></h2>
            <p>
              We bring strategy, design and development into one focused process.
              That means fewer handovers, clearer decisions and an end result
              built around what your business is trying to achieve.
            </p>
            <a className="text-link" href="#contact">Work with us <Arrow /></a>
          </div>
          <div className="principle-list">
            {principles.map((principle) => (
              <article key={principle.number} data-reveal>
                <span>{principle.number}</span>
                <div><h3>{principle.title}</h3><p>{principle.copy}</p></div>
              </article>
            ))}
          </div>
        </section>

        <section className="process section" id="process">
          <div className="process-heading" data-reveal>
            <div className="kicker"><span /> How we work</div>
            <h2>A clear path from<br /><em>idea to impact.</em></h2>
            <p>No black box. You’ll always know what is happening, why it matters and what comes next.</p>
          </div>
          <ol className="process-list">
            {process.map(([number, title, copy]) => (
              <li key={number} data-reveal>
                <span>{number}</span>
                <h3>{title}</h3>
                <p>{copy}</p>
              </li>
            ))}
          </ol>
        </section>

        <section className="pricing section" id="pricing">
          <div className="pricing-heading" data-reveal>
            <div>
              <div className="kicker dark"><span /> Starting points</div>
              <h2>Clear options.<br /><em>Thoughtfully scoped.</em></h2>
            </div>
            <p>Every project is tailored after discovery. These packages provide a transparent place to begin.</p>
          </div>
          <div className="pricing-grid">
            {packages.map((item) => (
              <article className={item.featured ? "price-card featured" : "price-card"} key={item.name} data-reveal>
                {item.featured && <small className="recommended">Recommended</small>}
                <span className="package-name">{item.name}</span>
                <strong>{item.price}</strong>
                <small className="price-suffix">{item.suffix}</small>
                <p>{item.description}</p>
                <ul>
                  {item.items.map((value) => <li key={value}><span>✓</span>{value}</li>)}
                </ul>
                <a
                  className={item.featured ? "button button-gold" : "button button-outline"}
                  href="#contact"
                  onClick={() => setSelectedPackage(item.name)}
                >
                  Choose {item.name} <Arrow />
                </a>
              </article>
            ))}
          </div>
          <div className="comparison" data-reveal>
            <div className="comparison-title">
              <div><span>Compare packages</span><h3>What’s included at a glance</h3></div>
              <small>Scroll horizontally on smaller screens</small>
            </div>
            <div className="comparison-scroll">
              <table>
                <thead>
                  <tr><th>Feature</th>{packages.map((item) => <th className={item.featured ? "highlight" : ""} key={item.name}>{item.name}</th>)}</tr>
                </thead>
                <tbody>
                  {comparisons.map(([feature, ...values]) => (
                    <tr key={feature}>
                      <th>{feature}</th>
                      {values.map((value, index) => <td className={index === 1 ? "highlight" : ""} key={`${feature}-${index}`}>{value}</td>)}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
          <p className="pricing-note">
            Domains, hosting, paid plugins or software, advertising and substantial
            content creation may be billed separately. Final pricing is confirmed
            after scope and requirements are agreed.
          </p>
          <div className="package-help">
            <div><span>Not sure which package fits?</span><p>Tell us what you want to achieve and we’ll recommend the most practical option.</p></div>
            <a className="button button-dark" href="#contact">Help me choose <Arrow /></a>
          </div>
        </section>

        <section className="faq section" id="faq">
          <div className="faq-heading" data-reveal>
            <div className="kicker dark"><span /> Frequently asked</div>
            <h2>Useful answers before<br /><em>we get started.</em></h2>
            <p>Need something more specific? Send an enquiry and we’ll give you a clear answer.</p>
          </div>
          <div className="faq-list">
            {faqs.map(([question, answer], index) => (
              <details key={question} data-reveal>
                <summary><span>0{index + 1}</span>{question}<Plus open={false} /></summary>
                <p>{answer}</p>
              </details>
            ))}
          </div>
        </section>

        <section className="contact section" id="contact">
          <div className="contact-copy" data-reveal>
            <div className="kicker"><span /> Start a conversation</div>
            <h2>Ready to build something that <em>works harder?</em></h2>
            <p>
              Tell us about your business, your challenge and where you want to go.
              We’ll respond with a practical next step—without the sales pressure.
            </p>
            <div className="contact-direct">
              <span>Prefer a direct channel?</span>
              <a href="mailto:hello@mtika.co.za">hello@mtika.co.za <Arrow diagonal /></a>
              <a
                className="whatsapp-link"
                href="https://wa.me/?text=Hi%20Mtika%20Web%20Solutions%2C%20I%27d%20like%20to%20discuss%20a%20project."
                target="_blank"
                rel="noreferrer"
              >
                Open WhatsApp <Arrow diagonal />
              </a>
            </div>
          </div>

          <div className="form-panel" data-reveal>
            {submitted ? (
              <div className="form-success" role="status">
                <span>Enquiry received</span>
                <h3>Thank you for reaching out.</h3>
                <p>We’ll review your project details and reply within two business days.</p>
                <button type="button" onClick={() => setSubmitted(false)}>Send another enquiry</button>
              </div>
            ) : (
              <form onSubmit={submitForm}>
                <div className="field-row">
                  <label><span>Name</span><input name="name" autoComplete="name" required placeholder="Your name" /></label>
                  <label><span>Email</span><input name="email" type="email" autoComplete="email" required placeholder="you@company.co.za" /></label>
                </div>
                <label><span>Business name</span><input name="company" autoComplete="organization" placeholder="Your business" /></label>
                <div className="field-row">
                  <label>
                    <span>Project type</span>
                    <select value={selectedPackage} onChange={(event) => setSelectedPackage(event.target.value)} name="package">
                      {packages.map((item) => <option key={item.name}>{item.name}</option>)}
                      <option>Not sure yet</option>
                    </select>
                  </label>
                  <label>
                    <span>Ideal timeline</span>
                    <select name="timeline" defaultValue="">
                      <option value="" disabled>Select a timeline</option>
                      <option>As soon as possible</option>
                      <option>1–2 months</option>
                      <option>3–6 months</option>
                      <option>Still exploring</option>
                    </select>
                  </label>
                </div>
                <label>
                  <span>What can we help you achieve?</span>
                  <textarea name="message" rows={5} required placeholder="Share a little about your goals and what you need..." />
                </label>
                <button className="button button-gold form-submit" type="submit">Send Project Enquiry <Arrow /></button>
                <small>Your details are only used to respond to this enquiry.</small>
              </form>
            )}
          </div>
        </section>

        <section className="final-cta section">
          <div data-reveal>
            <span>Have a project in mind?</span>
            <h2>Let’s create your next<br /><em>competitive advantage.</em></h2>
          </div>
          <a className="button button-dark" href="#contact">Start a Project <Arrow /></a>
        </section>
      </main>

      <footer>
        <div className="footer-main">
          <div>
            <a className="logo footer-logo" href="#top">
              <span className="logo-mark">M</span>
              <span>MTIKA <b>WEB SOLUTIONS</b></span>
            </a>
            <p>Strategy, design and technology for ambitious South African businesses.</p>
          </div>
          <div className="footer-column"><span>Explore</span><a href="#services">Services</a><a href="#work">Our Work</a><a href="#process">Process</a></div>
          <div className="footer-column"><span>Connect</span><a href="#contact">Start a Project</a><a href="mailto:hello@mtika.co.za">Email us</a></div>
        </div>
        <div className="footer-bottom">
          <span>© {new Date().getFullYear()} Mtika Web Solutions</span>
          <span>Johannesburg, South Africa · Working nationwide</span>
          <a href="#top">Back to top ↑</a>
        </div>
      </footer>

      <a className="mobile-project-cta" href="#contact">Start a Project <Arrow /></a>
    </div>
  );
}
